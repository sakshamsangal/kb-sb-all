package com.app.shared.util;

public class AppConstant {

    public static final String PAYLOAD = "payload";

    private AppConstant() {
    }


}
