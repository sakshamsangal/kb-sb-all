package com.app.util;

public class AppConstant {

    public static final String PAYLOAD = "payload";

    private AppConstant() {
    }


}
