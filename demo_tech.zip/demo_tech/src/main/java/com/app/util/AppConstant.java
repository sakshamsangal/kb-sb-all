package com.app.util;

public class AppConstant {

    public static final Object PROJECT_NAME = "demo";

    private AppConstant() {
    }


}
